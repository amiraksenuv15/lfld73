/* ============================================================
   admin-extras.js — модуль расширений админки
   ============================================================ */
(function () {
  'use strict';

  if (typeof window.tournamentsData === 'undefined') {
    console.warn('[admin-extras] основной скрипт не загружен');
    return;
  }

  var clubsData = window.clubsData;
  var tournamentsData = window.tournamentsData;
  var mrState = { matchId: null, tourneyKey: null, t1: '', t2: '', activeTeam: 1, goals1: [], goals2: [], cards: [] };
  var rpState = { tourneyKey: null, groups: [] };

  /* ============================================================
     КЛУБЫ
     ============================================================ */
  function loadCustomClubs() {
    var list = [];
    try { list = JSON.parse(localStorage.getItem('ff_custom_clubs') || '[]'); } catch (e) {}
    var changed = false;
    list.forEach(function (c) {
      if (!c || !c.name) return;
      if (!clubsData.find(function (x) { return x.name === c.name; })) {
        clubsData.push({ name: c.name, logo: c.logo || '⚽' });
        changed = true;
      }
    });
    if (changed && window.renderSidebar) window.renderSidebar();
  }
  function persistNewClub(name, logo) {
    var list = [];
    try { list = JSON.parse(localStorage.getItem('ff_custom_clubs') || '[]'); } catch (e) {}
    if (!list.find(function (c) { return c.name === name; })) {
      list.push({ name: name, logo: logo });
      localStorage.setItem('ff_custom_clubs', JSON.stringify(list));
    }
  }

  /* ============================================================
     ФОН
     ============================================================ */
  function applyBackground() {
    var bg = localStorage.getItem('custom_site_bg');
    if (bg) {
      document.body.style.setProperty('background',
        'linear-gradient(rgba(8,9,12,0.85),rgba(8,9,12,0.85)), url(' + bg + ') center/cover fixed no-repeat',
        'important');
    } else {
      document.body.style.removeProperty('background');
    }
  }
  function compressImage(file, maxW, quality, cb) {
    var r = new FileReader();
    r.onload = function (e) {
      var img = new Image();
      img.onload = function () {
        var s = Math.min(1, maxW / img.width);
        var c = document.createElement('canvas');
        c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        cb(c.toDataURL('image/jpeg', quality));
      };
      img.onerror = function () { cb(e.target.result); };
      img.src = e.target.result;
    };
    r.readAsDataURL(file);
  }
  function saveCustomBg() {
    var input = document.getElementById('bgFileInput');
    if (!input || !input.files[0]) return alert('Выберите файл изображения!');
    var f = input.files[0];
    if (!/^image\//.test(f.type)) return alert('Это не изображение.');
    compressImage(f, 1920, 0.85, function (dataUrl) {
      try { localStorage.setItem('custom_site_bg', dataUrl); applyBackground(); alert('Фон установлен!'); renderAdminExtras(); }
      catch (e) { alert('Файл слишком большой.'); }
    });
  }
  function resetCustomBg() {
    if (!confirm('Сбросить фон?')) return;
    localStorage.removeItem('custom_site_bg'); applyBackground(); renderAdminExtras();
  }

  /* ============================================================
     HERO
     ============================================================ */
  function getHeroPhotos() { try { return JSON.parse(localStorage.getItem('hero_slider_photos') || '[]'); } catch (e) { return []; } }
  function setHeroPhotos(list) { localStorage.setItem('hero_slider_photos', JSON.stringify(list)); if (window.initHeroCarousel) window.initHeroCarousel(); }
  function addHeroPhotos() {
    var input = document.getElementById('heroPhotosInput');
    if (!input || !input.files.length) return alert('Выберите файлы!');
    var files = Array.from(input.files).slice(0, 10);
    var current = getHeroPhotos();
    var toAdd = files.slice(0, Math.max(0, 10 - current.length));
    if (!toAdd.length) return alert('Максимум 10 фото.');
    var done = 0;
    toAdd.forEach(function (f) {
      compressImage(f, 1600, 0.85, function (dataUrl) {
        current.push(dataUrl); done++;
        if (done === toAdd.length) { setHeroPhotos(current); alert('Добавлено: ' + toAdd.length); renderAdminExtras(); }
      });
    });
  }
  function removeHeroPhoto(i) { if (!confirm('Удалить фото?')) return; var l = getHeroPhotos(); l.splice(i, 1); setHeroPhotos(l); renderAdminExtras(); }
  function clearHeroPhotos() { if (!confirm('Удалить все фото?')) return; setHeroPhotos([]); renderAdminExtras(); }

  /* ============================================================
     ROSTER HELPERS
     ============================================================ */
  function normalizeName(s) {
    return (s || '').toLowerCase().replace(/ё/g, 'е').replace(/[^а-яa-z0-9\s\-]/gi, '').replace(/\s+/g, ' ').trim();
  }
  function getAllRegisteredPlayers() {
    var players = {};
    function addP(name, club, tk) {
      var k = normalizeName(name);
      if (!k || k.length < 3) return;
      if (!players[k]) players[k] = { name: name, clubs: [], tournaments: [], lastClub: null };
      if (club && players[k].clubs.indexOf(club) === -1) players[k].clubs.push(club);
      if (tk && players[k].tournaments.indexOf(tk) === -1) players[k].tournaments.push(tk);
      if (club) players[k].lastClub = club;
    }
    Object.keys(tournamentsData).forEach(function (tk) {
      var t = tournamentsData[tk]; if (!t) return;
      if (t.rosters) Object.keys(t.rosters).forEach(function (club) { (t.rosters[club] || []).forEach(function (n) { addP(n, club, tk); }); });
      (t.matches || []).forEach(function (m) {
        if (m.scorers) m.scorers.split(';').forEach(function (part) {
          var sp = part.split(':'); if (sp.length < 2) return;
          var club = sp[0].trim(); var rest = sp.slice(1).join(':'); var ev = rest.split('ЖК:');
          ev[0].split(',').forEach(function (tok) {
            tok = tok.trim().replace(/\(\d+\)/g, '').trim();
            if (!tok || tok.indexOf('Автогол') !== -1 || tok.indexOf('(АГ)') !== -1 || tok.indexOf('Техническая') !== -1) return;
            addP(tok, club, tk);
          });
          if (ev[1]) ev[1].split(',').forEach(function (ct) { var n = ct.replace(/КК:.*$/, '').trim(); if (n) addP(n, club, tk); });
        });
        (m.events || []).forEach(function (e) { if (e.player) addP(e.player, e.club, tk); if (e.assist) addP(e.assist, e.club, tk); });
      });
    });
    return players;
  }
  function parseRosterText(text) { return !text ? [] : text.split(/[,;\n\r]+/).map(function (s) { return s.trim().replace(/\s+/g, ' '); }).filter(Boolean); }
  function matchPlayers(names, db) {
    return names.map(function (name) {
      var k = normalizeName(name); var found = db[k] || null;
      if (!found && k) { var ln = k.split(' ')[0]; if (ln.length >= 3) { var ms = Object.keys(db).filter(function (kk) { return kk.split(' ')[0] === ln; }); if (ms.length === 1) found = db[ms[0]]; } }
      return { entered: name, profileName: found ? found.name : name, status: found ? 'found' : 'new', previousClubs: found ? found.clubs.slice() : [] };
    });
  }
  function cleanPlayerName(raw) {
    var s = String(raw || '');
    s = s.replace(/^\s*\d+\s*[.)\-–—:]\s*/, '').replace(/^\s*[\-–—•*·>]+\s*/, '');
    s = s.replace(/\([^)]*\)/g, ' ').replace(/\[[^\]]*\]/g, ' ');
    s = s.replace(/\b(вратарь|защитник|полузащитник|нападающий|капитан|в[рк]|гк|цз|лз|пз|цп|лп|пп|нп|gk|df|mf|fw|к)\b\.?/gi, ' ');
    s = s.replace(/\b[гд]\.?р\.?\b/gi, ' ');
    s = s.replace(/[\-–—:;,.]+$/g, '').replace(/\s+/g, ' ').trim();
    s = s.replace(/[^а-яa-z\s\-]/gi, '').trim();
    if (!s || s.length < 3) return '';
    if (!/[а-яa-z]/i.test(s)) return '';
    return s.split(/\s+/).map(function (w) { return w ? w.charAt(0).toUpperCase() + w.slice(1).toLowerCase() : ''; }).filter(Boolean).join(' ');
  }
  function findClubInLine(line) {
    var clean = line.trim(); if (!clean) return null;
    var nLine = normalizeName(clean);
    for (var i = 0; i < clubsData.length; i++) {
      var nName = normalizeName(clubsData[i].name); if (!nName) continue;
      var re = new RegExp('(^|[^а-яa-z0-9])' + nName.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') + '([^а-яa-z0-9]|$)', 'i');
      if (re.test(nLine)) return clubsData[i].name;
    }
    var mQ = clean.match(/[«"]([^»"]+)[»"]/);
    if (mQ) { var c1 = mQ[1].trim(); if (c1 && c1.length >= 2 && c1.length <= 30) return c1; }
    var mP = clean.match(/^(?:фк|команда|клуб|состав|заявка)\s*[:\-—]?\s*(.+)$/i);
    if (mP) { var c2 = mP[1].replace(/[«»"\[\]:;,.]/g, '').trim(); if (c2 && c2.length >= 2 && c2.length <= 30) return c2; }
    return null;
  }
  function isTitleLine(line) {
    var clean = line.trim(); if (!clean) return false; if (clean.length > 80) return false;
    if (/^(фк|команда|клуб|состав|заявка)\s*[:\-—]/i.test(clean)) return true;
    var nLine = normalizeName(clean);
    for (var i = 0; i < clubsData.length; i++) { if (nLine === normalizeName(clubsData[i].name)) return true; }
    var m = clean.match(/^[«"]([^»"]+)[»"]\s*:?\s*$/); if (m && m[1].trim().length >= 2) return true;
    if (/^([А-ЯЁA-Z][а-яёa-z\-]+\s+){1,2}[А-ЯЁA-Z][а-яёa-z\-]*$/.test(clean.replace(/^\d+\s*[.)\-—]?\s*/, ''))) return false;
    for (var j = 0; j < clubsData.length; j++) {
      var cN = normalizeName(clubsData[j].name); if (!cN) continue;
      var re = new RegExp('(^|[^а-яa-z0-9])' + cN.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') + '([^а-яa-z0-9]|$)', 'i');
      if (re.test(nLine) && clean.length < 50) return true;
    }
    return false;
  }
  function parseAiRoster(text) {
    var lines = text.split(/\r?\n/); var groups = []; var current = null;
    lines.forEach(function (rawLine) {
      var line = rawLine.trim(); if (!line) return;
      if (isTitleLine(line)) {
        var clubName = findClubInLine(line);
        if (clubName) {
          var rest = ''; var mColon = line.match(/[:\-—]\s*(.+)$/); if (mColon) rest = mColon[1].trim();
          current = { club: clubName, players: [] }; groups.push(current);
          if (rest && rest !== line && rest.length > 3) rest.split(/[,;]+/).forEach(function (p) { var c = cleanPlayerName(p); if (c) current.players.push(c); });
          return;
        }
      }
      if (!current) { current = { club: '— не указано —', players: [] }; groups.push(current); }
      line.split(/[,;]+/).forEach(function (p) { var c = cleanPlayerName(p); if (c && c.length >= 3) current.players.push(c); });
    });
    return groups.filter(function (g) { return g.players.length > 0; });
  }
  function determinePlayerStatus(playerName, targetClub, allPlayers) {
    var k = normalizeName(playerName); var p = allPlayers[k];
    if (!p) return { code: 'newbie', label: 'Новичок', fromClub: null };
    if (p.clubs.indexOf(targetClub) !== -1) return { code: 'stay', label: 'Остался в клубе', fromClub: targetClub };
    var from = p.lastClub || (p.clubs.length ? p.clubs[p.clubs.length - 1] : null);
    return { code: 'transfer', label: 'Трансфер из «' + (from || '?') + '»', fromClub: from };
  }

  /* ============================================================
     МОДАЛКА ПРЕДПРОСМОТРА AI
     ============================================================ */
  function openRosterPreview(tourneyKey, groups) {
    rpState.tourneyKey = tourneyKey; rpState.groups = groups;
    var allPlayers = getAllRegisteredPlayers(); var html = '';
    var total = 0, stay = 0, trans = 0, nw = 0;
    groups.forEach(function (g) { g.players.forEach(function (p) { total++; var st = determinePlayerStatus(p, g.club, allPlayers); if (st.code === 'stay') stay++; else if (st.code === 'transfer') trans++; else nw++; }); });
    html += '<div class="rp-stats"><div class="rp-stat"><span class="dot stay"></span> Остались: <strong>' + stay + '</strong></div><div class="rp-stat"><span class="dot transfer"></span> Трансферы: <strong>' + trans + '</strong></div><div class="rp-stat"><span class="dot newbie"></span> Новички: <strong>' + nw + '</strong></div><div class="rp-stat">Всего: <strong>' + total + '</strong></div></div>';
    groups.forEach(function (g, gi) {
      html += '<div class="rp-club-block" data-gi="' + gi + '">';
      html += '<div class="rp-club-header"><div class="rp-club-name">' + g.club + '</div><div class="rp-club-count">' + g.players.length + ' игроков</div></div>';
      html += '<div class="rp-club-hint">Можно менять ФИО, перемещать селектом или удалять ✕</div>';
      g.players.forEach(function (p, pi) {
        var st = determinePlayerStatus(p, g.club, allPlayers);
        var clubOpts = clubsData.map(function (c) { return '<option value="' + c.name + '"' + (c.name === g.club ? ' selected' : '') + '>' + c.name + '</option>'; }).join('');
        html += '<div class="rp-player-row" data-gi="' + gi + '" data-pi="' + pi + '">';
        html += '<div class="rp-player-num">' + (pi + 1) + '</div>';
        html += '<input type="text" class="rp-player-name" value="' + p.replace(/"/g, '&quot;') + '" oninput="window.__rpUpdateName(' + gi + ',' + pi + ',this.value)">';
        html += '<div class="rp-status-badge ' + st.code + '">' + st.label + '</div>';
        html += '<select class="rp-club-select" onchange="window.__rpMovePlayer(' + gi + ',' + pi + ',this.value)">' + clubOpts + '</select>';
        html += '<button class="rp-delete-btn" onclick="window.__rpDeletePlayer(' + gi + ',' + pi + ')">✕</button>';
        html += '</div>';
      });
      html += '</div>';
    });
    document.getElementById('rpBody').innerHTML = html;
    document.getElementById('rpSubtitle').innerText = 'Турнир: ' + tournamentsData[tourneyKey].title;
    document.getElementById('rosterPreviewModal').style.display = 'flex';
  }
  function closeRosterPreview() { document.getElementById('rosterPreviewModal').style.display = 'none'; }
  function saveRosterPreview() {
    var tk = rpState.tourneyKey; if (!tk || !tournamentsData[tk]) return alert('Турнир не найден');
    var blocks = document.querySelectorAll('#rpBody .rp-club-block');
    var finalRosters = JSON.parse(JSON.stringify(tournamentsData[tk].rosters || {}));
    var clubsIn = {};
    blocks.forEach(function (b) { b.querySelectorAll('.rp-player-row').forEach(function (r) { var s = r.querySelector('.rp-club-select'); if (s) clubsIn[s.value] = 1; }); });
    Object.keys(clubsIn).forEach(function (c) { finalRosters[c] = []; });
    blocks.forEach(function (b) {
      b.querySelectorAll('.rp-player-row').forEach(function (r) {
        var n = r.querySelector('.rp-player-name'); var c = r.querySelector('.rp-club-select');
        if (!n || !c) return;
        var name = n.value.trim(); var club = c.value; if (!name || !club) return;
        if (!finalRosters[club]) finalRosters[club] = [];
        if (!finalRosters[club].some(function (x) { return normalizeName(x) === normalizeName(name); })) finalRosters[club].push(name);
      });
    });
    tournamentsData[tk].rosters = finalRosters;
    (tournamentsData[tk].teams || []).forEach(function (c) { if (!tournamentsData[tk].rosters[c]) tournamentsData[tk].rosters[c] = []; });
    if (window.saveTournamentsToStorage) window.saveTournamentsToStorage();
    var total = Object.keys(finalRosters).reduce(function (s, c) { return s + finalRosters[c].length; }, 0);
    alert('Заявки сохранены! Игроков: ' + total);
    closeRosterPreview();
    if (window.renderTourney) window.renderTourney();
  }
  function runAiParse() {
    var tk = document.getElementById('aiTourney').value;
    var text = (document.getElementById('aiTextarea').value || '').trim();
    var statusEl = document.getElementById('aiStatus');
    function show(msg, ok) { statusEl.className = 'ai-status show ' + (ok ? 'ok' : 'err'); statusEl.innerText = msg; }
    if (!tk) return show('Выберите турнир', false);
    if (!text) return show('Вставьте текст', false);
    var groups = parseAiRoster(text);
    if (!groups.length) return show('Не удалось распознать', false);
    var total = groups.reduce(function (s, g) { return s + g.players.length; }, 0);
    groups.forEach(function (g) {
      if (!clubsData.find(function (c) { return c.name === g.club; }) && g.club !== '— не указано —') {
        clubsData.push({ name: g.club, logo: '⚽' }); persistNewClub(g.club, '⚽');
      }
    });
    if (window.renderSidebar) window.renderSidebar();
    show('Распознано команд: ' + groups.length + ', игроков: ' + total, true);
    openRosterPreview(tk, groups);
  }
  function handleAiFile(file) {
    if (!file) return;
    var name = (file.name || '').toLowerCase();
    if (name.endsWith('.docx')) { alert('DOCX не поддерживается.'); return; }
    var r = new FileReader();
    r.onload = function (e) { document.getElementById('aiTextarea').value = e.target.result; var s = document.getElementById('aiStatus'); s.className = 'ai-status show ok'; s.innerText = 'Файл: ' + file.name; };
    r.onerror = function () { alert('Ошибка чтения'); };
    r.readAsText(file, 'UTF-8');
  }

  /* ============================================================
     ROSTER КЛУБА
     ============================================================ */
  function getRosterOfClub(tk, club) {
    var t = tournamentsData[tk]; if (!t) return [];
    if (t.rosters && t.rosters[club] && t.rosters[club].length) return t.rosters[club].slice().sort();
    var players = {};
    (t.matches || []).forEach(function (m) {
      if (!m.scorers) return;
      if (m.t1 !== club && m.t2 !== club) return;
      m.scorers.split(';').forEach(function (part) {
        var sp = part.split(':'); if (sp.length < 2) return;
        var c = sp[0].trim(); if (c !== club) return;
        var ev = sp.slice(1).join(':').split('ЖК:');
        ev[0].split(',').forEach(function (tok) {
          tok = tok.trim().replace(/\(\d+\)/g, '').trim();
          if (!tok || tok.indexOf('Автогол') !== -1 || tok.indexOf('(АГ)') !== -1 || tok.indexOf('Техническая') !== -1) return;
          players[tok] = 1;
        });
        if (ev[1]) ev[1].split(',').forEach(function (ct) { var n = ct.replace(/КК:.*$/, '').trim(); if (n) players[n] = 1; });
      });
      (m.events || []).forEach(function (e) { if (e.club === club && e.player) players[e.player] = 1; if (e.club === club && e.assist) players[e.assist] = 1; });
    });
    return Object.keys(players).sort();
  }

  /* ============================================================
     ПРОТОКОЛ МАТЧА
     ============================================================ */
  function openMatchResult(tk, idx) {
    var t = tournamentsData[tk]; if (!t || !t.matches[idx]) return;
    var m = t.matches[idx];
    mrState.tourneyKey = tk; mrState.matchId = idx; mrState.t1 = m.t1; mrState.t2 = m.t2; mrState.activeTeam = 1;
    mrState.goals1 = []; mrState.goals2 = []; mrState.cards = [];
    (m.events || []).forEach(function (e) {
      if (e.type === 'goal') {
        var arr = (e.club === m.t1) ? mrState.goals1 : mrState.goals2;
        arr.push({ player: e.player || '', assist: e.assist || '', minute: e.minute || '', type: e.ownGoal ? 'own' : (e.penalty ? 'penalty' : 'goal') });
      } else {
        mrState.cards.push({ club: e.club, player: e.player, type: e.type === 'red' ? 'red' : 'yellow', minute: e.minute || '' });
      }
    });
    document.getElementById('mrTitle').innerText = 'Протокол матча';
    document.getElementById('mrSubtitle').innerText = '[' + m.tour + '] ' + m.t1 + ' — ' + m.t2;
    document.getElementById('mrTeam1Label').innerText = m.t1;
    document.getElementById('mrTeam2Label').innerText = m.t2;
    document.getElementById('mrTab1Name').innerText = m.t1;
    document.getElementById('mrTab2Name').innerText = m.t2;
    document.getElementById('mrDate').value = m.date || '';
    document.getElementById('mrStadium').value = m.stadium || '';
    document.getElementById('mrStatus').value = m.status || 'finished';

    var mrStream = document.getElementById('mrStreamUrl');
    var mrReplay = document.getElementById('mrReplayUrl');
    var id = window.makeMatchId(tk, m);
    if (mrStream) mrStream.value = (window.streamLinks[id] && window.streamLinks[id].url) || '';
    if (mrReplay) mrReplay.value = (window.streamLinks[id] && window.streamLinks[id].replay) || '';

    var s1 = m.s1 || 0, s2 = m.s2 || 0;
    document.getElementById('mrScore1').value = s1;
    document.getElementById('mrScore2').value = s2;
    syncGoalsToScore(mrState.goals1, s1);
    syncGoalsToScore(mrState.goals2, s2);
    switchMrTeam(1); renderMrCards(); validateMr();
    document.getElementById('matchResultModal').style.display = 'flex';
  }
  function syncGoalsToScore(arr, n) {
    n = Math.max(0, parseInt(n) || 0);
    while (arr.length < n) arr.push({ player: '', assist: '', minute: '', type: 'goal' });
    while (arr.length > n) arr.pop();
  }
  function switchMrTeam(num) {
    mrState.activeTeam = num;
    var t1 = document.getElementById('mrTab1'); var t2 = document.getElementById('mrTab2');
    if (t1) t1.className = 'mr-tab' + (num === 1 ? ' active' : '');
    if (t2) t2.className = 'mr-tab' + (num === 2 ? ' active' : '');
    renderMrGoals();
  }
  function renderMrGoals() {
    var panel = document.getElementById('mrGoalsPanel'); if (!panel) return;
    var team = mrState.activeTeam === 1 ? mrState.t1 : mrState.t2;
    var arr = mrState.activeTeam === 1 ? mrState.goals1 : mrState.goals2;
    var roster = getRosterOfClub(mrState.tourneyKey, team);
    if (!arr.length) { panel.innerHTML = '<div class="mr-empty">Голов нет.</div>'; return; }
    var html = '<div class="mr-goals-panel">';
    arr.forEach(function (g, i) {
      var isOwn = g.type === 'own', isPen = g.type === 'penalty';
      var playerOpts = '<option value="">— игрок —</option>' + roster.map(function (p) { return '<option value="' + p.replace(/"/g, '&quot;') + '"' + (p === g.player ? ' selected' : '') + '>' + p + '</option>'; }).join('');
      var assistOpts = '<option value="">— без ассиста —</option>' + roster.map(function (p) { return '<option value="' + p.replace(/"/g, '&quot;') + '"' + (p === g.assist ? ' selected' : '') + '>' + p + '</option>'; }).join('');
      html += '<div class="mr-goal-slot">';
      html += '<div class="mr-goal-num">' + (i + 1) + '</div>';
      html += '<select onchange="window.__mrGoalPlayer(' + i + ',this.value)">' + playerOpts + '</select>';
      html += '<select onchange="window.__mrGoalAssist(' + i + ',this.value)"' + (isOwn ? ' disabled' : '') + '>' + assistOpts + '</select>';
      html += '<select onchange="window.__mrGoalType(' + i + ',this.value)"><option value="goal"' + (g.type === 'goal' ? ' selected' : '') + '>Гол</option><option value="penalty"' + (isPen ? ' selected' : '') + '>Пенальти</option><option value="own"' + (isOwn ? ' selected' : '') + '>Автогол</option></select>';
      html += '<input type="text" class="mr-minute" placeholder="мин." value="' + (g.minute || '') + '" oninput="window.__mrGoalMinute(' + i + ',this.value)">';
      html += '</div>';
    });
    html += '</div>'; panel.innerHTML = html;
  }
  window.__mrGoalPlayer = function (i, v) { var a = mrState.activeTeam === 1 ? mrState.goals1 : mrState.goals2; if (a[i]) a[i].player = v; };
  window.__mrGoalAssist = function (i, v) { var a = mrState.activeTeam === 1 ? mrState.goals1 : mrState.goals2; if (a[i]) a[i].assist = v; };
  window.__mrGoalType = function (i, v) { var a = mrState.activeTeam === 1 ? mrState.goals1 : mrState.goals2; if (a[i]) a[i].type = v; renderMrGoals(); };
  window.__mrGoalMinute = function (i, v) { var a = mrState.activeTeam === 1 ? mrState.goals1 : mrState.goals2; if (a[i]) a[i].minute = v; };

  function renderMrCards() {
    var container = document.getElementById('mrCardsList'); if (!container) return;
    if (!mrState.cards.length) { container.innerHTML = '<div class="mr-empty">Карточек нет</div>'; return; }
    var html = '';
    mrState.cards.forEach(function (c, i) {
      var roster = getRosterOfClub(mrState.tourneyKey, c.club);
      var playerOpts = '<option value="">— игрок —</option>' + roster.map(function (p) { return '<option value="' + p.replace(/"/g, '&quot;') + '"' + (p === c.player ? ' selected' : '') + '>' + p + '</option>'; }).join('');
      var clubOpts = '<option value="' + mrState.t1 + '"' + (c.club === mrState.t1 ? ' selected' : '') + '>' + mrState.t1 + '</option><option value="' + mrState.t2 + '"' + (c.club === mrState.t2 ? ' selected' : '') + '>' + mrState.t2 + '</option>';
      html += '<div class="mr-card-row">';
      html += '<div class="mr-card-type ' + c.type + '">●</div>';
      html += '<select onchange="window.__mrCardClub(' + i + ',this.value)">' + clubOpts + '</select>';
      html += '<select onchange="window.__mrCardPlayer(' + i + ',this.value)">' + playerOpts + '</select>';
      html += '<input type="text" placeholder="мин." value="' + (c.minute || '') + '" oninput="window.__mrCardMinute(' + i + ',this.value)">';
      html += '<button class="mr-del" onclick="window.__mrCardDelete(' + i + ')">✕</button></div>';
    });
    container.innerHTML = html;
  }
  window.__mrCardClub = function (i, v) { if (mrState.cards[i]) { mrState.cards[i].club = v; mrState.cards[i].player = ''; } renderMrCards(); };
  window.__mrCardPlayer = function (i, v) { if (mrState.cards[i]) mrState.cards[i].player = v; };
  window.__mrCardMinute = function (i, v) { if (mrState.cards[i]) mrState.cards[i].minute = v; };
  window.__mrCardDelete = function (i) { mrState.cards.splice(i, 1); renderMrCards(); };
  function addMrCard() { if (!mrState.tourneyKey) return; mrState.cards.push({ club: mrState.t1, player: '', type: 'yellow', minute: '' }); renderMrCards(); }
  function validateMr() {
    var el = document.getElementById('mrValidation'); if (!el) return true;
    var s1 = parseInt(document.getElementById('mrScore1').value) || 0;
    var s2 = parseInt(document.getElementById('mrScore2').value) || 0;
    var g1 = mrState.goals1.filter(function (g) { return g.player; }).length;
    var g2 = mrState.goals2.filter(function (g) { return g.player; }).length;
    var msg = '', ok = true;
    if (g1 !== s1) { msg += 'Голы ' + mrState.t1 + ': ' + g1 + '/' + s1 + '. '; ok = false; }
    if (g2 !== s2) { msg += 'Голы ' + mrState.t2 + ': ' + g2 + '/' + s2 + '. '; ok = false; }
    if (ok) msg = 'Все голы распределены.';
    el.className = 'mr-validation show ' + (ok ? 'ok' : 'err');
    el.innerText = msg; return ok;
  }
  function buildScorersText() {
    var goals = {}, cards = {};
    function addG(c, n) { if (!n) return; if (!goals[c]) goals[c] = []; goals[c].push(n); }
    mrState.goals1.forEach(function (g) { if (g.type === 'own') addG(mrState.t2, g.player); else addG(mrState.t1, g.player); });
    mrState.goals2.forEach(function (g) { if (g.type === 'own') addG(mrState.t1, g.player); else addG(mrState.t2, g.player); });
    mrState.cards.forEach(function (c) { if (!cards[c.club]) cards[c.club] = { y: [], r: [] }; if (c.type === 'red') cards[c.club].r.push(c.player); else cards[c.club].y.push(c.player); });
    var all = {}; Object.keys(goals).forEach(function (c) { all[c] = 1; }); Object.keys(cards).forEach(function (c) { all[c] = 1; });
    var parts = [];
    Object.keys(all).forEach(function (club) {
      var line = club + ': ';
      var gg = goals[club] || []; var cnt = {};
      gg.forEach(function (p) { cnt[p] = (cnt[p] || 0) + 1; });
      var gs = Object.keys(cnt).map(function (p) { return cnt[p] > 1 ? p + ' (' + cnt[p] + ')' : p; }).join(', ');
      line += gs || '—';
      if (cards[club]) {
        var cs = [];
        if (cards[club].y.length) cs.push(cards[club].y.join(', '));
        if (cards[club].r.length) cs.push('КК: ' + cards[club].r.join(', '));
        if (cs.length) line += ', ЖК: ' + cs.join(', ');
      }
      parts.push(line);
    });
    return parts.join('; ');
  }
  function saveMatchResult() {
    var tk = mrState.tourneyKey; var idx = mrState.matchId;
    if (!tournamentsData[tk]) return;
    var s1 = parseInt(document.getElementById('mrScore1').value) || 0;
    var s2 = parseInt(document.getElementById('mrScore2').value) || 0;
    syncGoalsToScore(mrState.goals1, s1); syncGoalsToScore(mrState.goals2, s2);
    var m = tournamentsData[tk].matches[idx];
    m.s1 = s1; m.s2 = s2;
    m.date = document.getElementById('mrDate').value;
    m.stadium = document.getElementById('mrStadium').value;
    m.status = document.getElementById('mrStatus').value;
    m.played = (m.status === 'finished' || s1 > 0 || s2 > 0);
    var events = [];
    mrState.goals1.forEach(function (g) { events.push({ type: 'goal', club: mrState.t1, player: g.player, assist: g.assist, minute: g.minute, penalty: g.type === 'penalty', ownGoal: g.type === 'own' }); });
    mrState.goals2.forEach(function (g) { events.push({ type: 'goal', club: mrState.t2, player: g.player, assist: g.assist, minute: g.minute, penalty: g.type === 'penalty', ownGoal: g.type === 'own' }); });
    mrState.cards.forEach(function (c) { events.push({ type: c.type, club: c.club, player: c.player, minute: c.minute }); });
    m.scorers = buildScorersText();
    m.events = events;

    if (window.streamLinks && window.makeMatchId && window.saveStreamLinks) {
      var id = window.makeMatchId(tk, m);
      var streamUrl = (document.getElementById('mrStreamUrl') || {}).value || '';
      var replayUrl = (document.getElementById('mrReplayUrl') || {}).value || '';
      if (streamUrl || replayUrl) {
        window.streamLinks[id] = { url: streamUrl, replay: replayUrl, status: m.status === 'live' ? 'live' : (replayUrl ? 'replay' : 'none') };
        if (window.vkLiveLinks) window.vkLiveLinks[id] = streamUrl || '';
        if (window.saveVkLiveLinks) window.saveVkLiveLinks();
      } else {
        delete window.streamLinks[id];
        if (window.vkLiveLinks) delete window.vkLiveLinks[id];
      }
      window.saveStreamLinks();
    }

    if (window.saveTournamentsToStorage) window.saveTournamentsToStorage();
    if (window.renderTourney) window.renderTourney();
    if (window.updateDynamicTabs) window.updateDynamicTabs();
    document.getElementById('matchResultModal').style.display = 'none';
    renderFbList();
    alert('Протокол сохранён!');
  }

  /* ============================================================
     РАСПИСАНИЕ
     ============================================================ */
  function getAllTeamsOfTourney(tk) { return (tournamentsData[tk] && tournamentsData[tk].teams) || []; }
  function getExistingTours(tk) { var t = tournamentsData[tk]; if (!t) return []; var s = {}; (t.matches || []).forEach(function (m) { s[m.tour] = 1; }); return Object.keys(s); }
  function teamBusyInTour(tk, tour, team) { return (tournamentsData[tk].matches || []).filter(function (m) { return m.tour === tour; }).some(function (m) { return m.t1 === team || m.t2 === team; }); }
  function headToHead(tk, a, b) { return (tournamentsData[tk].matches || []).filter(function (m) { return (m.t1 === a && m.t2 === b) || (m.t1 === b && m.t2 === a); }); }
  function updateFbTeams() {
    var tk = document.getElementById('fbTourney').value;
    var teams = getAllTeamsOfTourney(tk);
    var opts = teams.map(function (t) { return '<option value="' + t + '">' + t + '</option>'; }).join('');
    var t1 = document.getElementById('fbT1'); var t2 = document.getElementById('fbT2');
    if (t1) t1.innerHTML = opts; if (t2) t2.innerHTML = opts;
    var dl = document.getElementById('fbToursList');
    if (dl) dl.innerHTML = getExistingTours(tk).map(function (t) { return '<option value="' + t + '">'; }).join('');
    renderFbList(); updateFbHint();
  }
  function updateFbHint() {
    var tk = document.getElementById('fbTourney').value;
    var tour = (document.getElementById('fbTour').value || '').trim();
    var t1 = document.getElementById('fbT1').value; var t2 = document.getElementById('fbT2').value;
    var hint = document.getElementById('fbHint'); if (!hint) return;
    if (!tour || !t1 || !t2) { hint.innerHTML = ''; return; }
    if (t1 === t2) { hint.innerHTML = '<div class="pair-hint err">Команды должны быть разными</div>'; return; }
    if (teamBusyInTour(tk, tour, t1)) { hint.innerHTML = '<div class="pair-hint err">«' + t1 + '» уже играет</div>'; return; }
    if (teamBusyInTour(tk, tour, t2)) { hint.innerHTML = '<div class="pair-hint err">«' + t2 + '» уже играет</div>'; return; }
    var hh = headToHead(tk, t1, t2);
    if (hh.length) hint.innerHTML = '<div class="pair-hint warn">Уже играли (' + hh[0].s1 + ':' + hh[0].s2 + ')</div>';
    else hint.innerHTML = '<div class="pair-hint ok">Команды ещё не играли</div>';
  }
  function addFbPair() {
    var tk = document.getElementById('fbTourney').value;
    var tour = (document.getElementById('fbTour').value || '').trim();
    var date = (document.getElementById('fbDate').value || '').trim();
    var t1 = document.getElementById('fbT1').value; var t2 = document.getElementById('fbT2').value;
    if (!tour) return alert('Укажите тур');
    if (t1 === t2) return alert('Команды разные');
    if (teamBusyInTour(tk, tour, t1) || teamBusyInTour(tk, tour, t2)) return alert('Команда занята');
    tournamentsData[tk].matches.push({ tour: tour, date: date, t1: t1, s1: 0, s2: 0, t2: t2, scorers: '', played: false, status: 'upcoming' });
    if (window.saveTournamentsToStorage) window.saveTournamentsToStorage();
    if (window.renderTourney) window.renderTourney();
    renderFbList(); updateFbHint(); alert('Матч назначен');
  }
  function renderFbList() {
    var tk = document.getElementById('fbTourney').value;
    var c = document.getElementById('fbList'); if (!c || !tournamentsData[tk]) return;
    var matches = (tournamentsData[tk].matches || []).slice().reverse();
    if (!matches.length) { c.innerHTML = '<p style="margin-top:10px;">Матчей пока нет</p>'; return; }
    var html = '';
    matches.forEach(function (m, i) {
      var realIdx = tournamentsData[tk].matches.length - 1 - i;
      var played = m.played !== false && m.s1 !== undefined && (m.s1 > 0 || m.s2 > 0 || m.played === true);
      html += '<div class="fixture-item"><span class="fixture-pair">[' + m.tour + '] ' + m.t1 + ' — ' + m.t2 + '</span><span class="fixture-status">' + (played ? m.s1 + ':' + m.s2 : 'Не сыгран') + '</span>';
      html += '<button onclick="window.__fbOpenResult(\'' + tk + '\',' + realIdx + ')" style="padding:5px 10px !important;font-size:11px;">Протокол</button>';
      html += '<button onclick="window.__fbDelete(\'' + tk + '\',' + realIdx + ')" class="btn-danger" style="padding:5px 10px !important;font-size:11px;">Удалить</button></div>';
    });
    c.innerHTML = html;
  }
  function showRemainingPairs() {
    var tk = document.getElementById('fbTourney').value; var teams = getAllTeamsOfTourney(tk);
    if (!teams.length) return alert('Нет команд');
    var rem = [];
    for (var i = 0; i < teams.length; i++) for (var j = i + 1; j < teams.length; j++) if (!headToHead(tk, teams[i], teams[j]).length) rem.push(teams[i] + ' — ' + teams[j]);
    if (!rem.length) return alert('Все пары сыграны!');
    alert('Осталось (' + rem.length + '):\n\n' + rem.join('\n'));
  }
  function generateRoundRobin() {
    var tk = document.getElementById('fbTourney').value; var teams = getAllTeamsOfTourney(tk).slice();
    if (teams.length < 2) return alert('Минимум 2 команды');
    if (!confirm('Сгенерировать круговой?')) return;
    var allPairs = [];
    for (var i = 0; i < teams.length; i++) for (var j = i + 1; j < teams.length; j++) if (!headToHead(tk, teams[i], teams[j]).length) allPairs.push([teams[i], teams[j]]);
    if (!allPairs.length) return alert('Все пары уже есть!');
    var tours = [];
    allPairs.forEach(function (pair) {
      var placed = false;
      for (var i = 0; i < tours.length; i++) {
        var inTour = []; tours[i].forEach(function (p) { inTour.push(p[0], p[1]); });
        if (inTour.indexOf(pair[0]) === -1 && inTour.indexOf(pair[1]) === -1) { tours[i].push(pair); placed = true; break; }
      }
      if (!placed) tours.push([pair]);
    });
    var existing = getExistingTours(tk); var maxN = 0;
    existing.forEach(function (t) { var n = parseInt((t || '').replace(/\D/g, '')) || 0; if (n > maxN) maxN = n; });
    var t = tournamentsData[tk];
    tours.forEach(function (tp, idx) {
      var tName = (maxN + idx + 1) + ' ТУР';
      tp.forEach(function (pair) { t.matches.push({ tour: tName, date: '', t1: pair[0], s1: 0, s2: 0, t2: pair[1], scorers: '', played: false, status: 'upcoming' }); });
    });
    if (window.saveTournamentsToStorage) window.saveTournamentsToStorage();
    if (window.renderTourney) window.renderTourney();
    renderFbList(); alert('Туров: ' + tours.length + ', матчей: ' + allPairs.length);
  }

  /* ============================================================
     VK LIVE MATCHER
     ============================================================ */
  function runVkMatcher() {
    var text = (document.getElementById('vkMatcherInput').value || '').trim();
    var statusEl = document.getElementById('vkMatcherStatus');
    function show(msg, cls) { statusEl.className = 'ai-status show ' + (cls || 'info'); statusEl.innerText = msg; }
    if (!text) return show('Вставьте ссылки', 'err');

    var lines = text.split(/\r?\n/).filter(function (l) { return l.trim(); });
    if (!lines.length) return show('Нет строк', 'err');

    var matched = 0, unmatched = [];

    lines.forEach(function (line) {
      var urlMatch = line.match(/https?:\/\/[^\s]+/);
      if (!urlMatch) return;
      var url = urlMatch[0];
      var rest = line.replace(url, ' ').trim();

      // Ищем два клуба в тексте
      var foundClubs = [];
      clubsData.forEach(function (c) {
        var nName = (c.name || '').toLowerCase().replace(/ё/g, 'е');
        var nRest = rest.toLowerCase().replace(/ё/g, 'е');
        if (nRest.indexOf(nName) !== -1 && foundClubs.indexOf(c.name) === -1) foundClubs.push(c.name);
      });

      if (foundClubs.length < 2) { unmatched.push(line); return; }

      // Ищем матч по этим клубам во всех турнирах
      var found = false;
      Object.keys(tournamentsData).forEach(function (tk) {
        if (found) return;
        (tournamentsData[tk].matches || []).forEach(function (m) {
          if (found) return;
          var t1L = (m.t1 || '').toLowerCase().replace(/ё/g, 'е');
          var t2L = (m.t2 || '').toLowerCase().replace(/ё/g, 'е');
          var c1L = foundClubs[0].toLowerCase().replace(/ё/g, 'е');
          var c2L = foundClubs[1].toLowerCase().replace(/ё/g, 'е');
          if ((t1L === c1L && t2L === c2L) || (t1L === c2L && t2L === c1L)) {
            var id = window.makeMatchId(tk, m);
            window.vkLiveLinks[id] = url;
            matched++;
            found = true;
          }
        });
      });

      if (!found) unmatched.push(line);
    });

    if (window.saveVkLiveLinks) window.saveVkLiveLinks();
    if (window.renderTourney) window.renderTourney();

    var msg = 'Привязано трансляций: ' + matched;
    if (unmatched.length) msg += '. Не удалось сопоставить: ' + unmatched.length;
    show(msg, matched ? 'ok' : 'err');
    renderAdminExtras();
  }

  /* ============================================================
     AI-АССИСТЕНТ (пресс-служба лиги)
     ============================================================ */
  function getAiKey() { return localStorage.getItem('ff_ai_key') || ''; }
  function getAiProvider() { return localStorage.getItem('ff_ai_provider') || 'local'; }
  function saveAiSettings() {
    var key = (document.getElementById('aiAssistantKey') || {}).value || '';
    var prov = (document.getElementById('aiAssistantProvider') || {}).value || 'local';
    localStorage.setItem('ff_ai_key', key);
    localStorage.setItem('ff_ai_provider', prov);
    alert('Настройки AI сохранены');
  }

  function generateLocalTourReport(tk) {
    var t = tournamentsData[tk];
    if (!t) return 'Турнир не найден.';

    var data = window.calculateStandings(tk);
    var out = [];
    out.push('ОБЗОР ТУРА: ' + t.title);
    out.push('');

    // Последний тур
    var tours = [];
    (t.matches || []).forEach(function (m) { if (tours.indexOf(m.tour) === -1) tours.push(m.tour); });
    tours.sort();
    var lastTour = tours[tours.length - 1];

    if (!lastTour) return 'Пока нет матчей.';

    var lastMatches = (t.matches || []).filter(function (m) { return m.tour === lastTour; });
    out.push('Тур: ' + lastTour);
    out.push('');

    lastMatches.forEach(function (m) {
      var played = m.played !== false && (m.s1 > 0 || m.s2 > 0 || m.played === true);
      if (!played) {
        out.push('• ' + m.t1 + ' — ' + m.t2 + ' (не сыгран)');
      } else {
        out.push('• ' + m.t1 + ' ' + m.s1 + ':' + m.s2 + ' ' + m.t2);
        if (m.scorers) {
          // Разберём авторов голов
          var g = {};
          m.scorers.split(';').forEach(function (part) {
            var sp = part.split(':');
            if (sp.length < 2) return;
            var club = sp[0].trim();
            var rest = sp.slice(1).join(':').split('ЖК:')[0].split('КК:')[0];
            var arr = [];
            rest.split(',').forEach(function (tk2) {
              tk2 = tk2.trim().replace(/[\s,]+$/, '');
              if (!tk2 || tk2.indexOf('Автогол') !== -1 || tk2.indexOf('(АГ)') !== -1 || tk2.indexOf('Техническая') !== -1) return;
              var cnt = 1;
              var mm = tk2.match(/\((\d+)\)/);
              if (mm) { cnt = parseInt(mm[1]) || 1; tk2 = tk2.replace(/\((\d+)\)/, '').trim(); }
              arr.push(tk2 + (cnt > 1 ? ' ×' + cnt : ''));
            });
            if (arr.length) g[club] = arr.join(', ');
          });
          Object.keys(g).forEach(function (club) {
            out.push('  ⚽ ' + club + ': ' + g[club]);
          });
        }
      }
    });
    out.push('');

    // Топ-3 таблицы
    if (data.stats.length >= 3) {
      out.push('ТУРНИРНАЯ ТАБЛИЦА (ТОП-3):');
      data.stats.slice(0, 3).forEach(function (s, i) {
        out.push((i + 1) + '. ' + s.name + ' — ' + s.pts + ' очк., ' + s.gf + ':' + s.ga);
      });
      out.push('');
    }

    // Лучшие игроки
    if (data.players.length) {
      var topScorers = data.players.slice().sort(function (a, b) { return b.goals - a.goals; }).slice(0, 3);
      if (topScorers.length && topScorers[0].goals > 0) {
        out.push('ЛУЧШИЕ БОМБАРДИРЫ:');
        topScorers.forEach(function (p) {
          if (p.goals > 0) out.push('• ' + p.name + ' (' + p.club + ') — ' + p.goals + ' голов');
        });
        out.push('');
      }
    }

    // Лучший игрок матча (автор максимума голов в последнем туре)
    var topInRound = {};
    lastMatches.forEach(function (m) {
      if (!m.scorers) return;
      m.scorers.split(';').forEach(function (part) {
        var sp = part.split(':');
        if (sp.length < 2) return;
        var club = sp[0].trim();
        var rest = sp.slice(1).join(':').split('ЖК:')[0].split('КК:')[0];
        rest.split(',').forEach(function (tk2) {
          tk2 = tk2.trim();
          if (!tk2 || tk2.indexOf('Автогол') !== -1 || tk2.indexOf('(АГ)') !== -1 || tk2.indexOf('Техническая') !== -1) return;
          var cnt = 1;
          var mm = tk2.match(/\((\d+)\)/);
          if (mm) { cnt = parseInt(mm[1]) || 1; tk2 = tk2.replace(/\((\d+)\)/, '').trim(); }
          var key = tk2 + '|' + club;
          topInRound[key] = (topInRound[key] || 0) + cnt;
        });
      });
    });
    var topRound = Object.keys(topInRound).map(function (k) {
      var pp = k.split('|');
      return { name: pp[0], club: pp[1], goals: topInRound[k] };
    }).sort(function (a, b) { return b.goals - a.goals; });

    if (topRound.length && topRound[0].goals > 0) {
      out.push('ЛУЧШИЙ ИГРОК ТУРА:');
      out.push('• ' + topRound[0].name + ' (' + topRound[0].club + ') — ' + topRound[0].goals + ' гол' + (topRound[0].goals > 1 ? 'а' : ''));
      out.push('');
    }

    out.push('Материал подготовлен пресс-службой ЛФЛД.');
    return out.join('\n');
  }

  function runAiReport() {
    var tk = window.getCurrentTourneyKey ? window.getCurrentTourneyKey() : '5x5';
    var key = getAiKey();
    var provider = getAiProvider();
    var outEl = document.getElementById('aiAssistantOutput');
    if (!outEl) return;

    if (!key || provider === 'local') {
      outEl.innerHTML = '<strong>Локальный отчёт (без API):</strong>\n\n' + generateLocalTourReport(tk).replace(/</g, '&lt;');
      return;
    }

    outEl.innerText = 'Генерация обзора через AI... (это может занять 10–30 сек)';
    var localData = generateLocalTourReport(tk);

    var prompt = 'Ты — спортивный журналист. На основе статистики ниже напиши живой обзор тура для сообщества ВКонтакте (2-3 абзаца, без markdown-разметки, живым русским языком):\n\n' + localData;

    var endpoint, body, headers = { 'Content-Type': 'application/json' };

    if (provider === 'openai') {
      endpoint = 'https://api.openai.com/v1/chat/completions';
      headers['Authorization'] = 'Bearer ' + key;
      body = JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt }], max_tokens: 600 });
    } else if (provider === 'deepseek') {
      endpoint = 'https://api.deepseek.com/chat/completions';
      headers['Authorization'] = 'Bearer ' + key;
      body = JSON.stringify({ model: 'deepseek-chat', messages: [{ role: 'user', content: prompt }], max_tokens: 600 });
    } else if (provider === 'gemini') {
      endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + key;
      body = JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] });
    } else {
      outEl.innerText = 'Провайдер не поддерживается';
      return;
    }

    fetch(endpoint, { method: 'POST', headers: headers, body: body })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var text = '';
        if (provider === 'gemini') {
          if (data.candidates && data.candidates[0] && data.candidates[0].content) text = data.candidates[0].content.parts[0].text;
        } else {
          if (data.choices && data.choices[0] && data.choices[0].message) text = data.choices[0].message.content;
        }
        if (!text) { outEl.innerText = 'Пустой ответ от AI. Показываю локальный:\n\n' + localData; return; }
        outEl.innerText = text;
      })
      .catch(function (err) {
        outEl.innerText = 'Ошибка запроса: ' + err.message + '\n\nЛокальный отчёт:\n\n' + localData;
      });
  }

  /* ============================================================
     РЕНДЕР СЕКЦИЙ АДМИНКИ
     ============================================================ */
  function renderBackgroundBlock() {
    var has = !!localStorage.getItem('custom_site_bg');
    return '<div class="admin-extras-section"><h3>Фоновое изображение сайта</h3>' +
      '<div class="form-group"><label>Файл:</label><input type="file" id="bgFileInput" accept="image/*"></div>' +
      '<button id="bgSaveBtn" class="btn-success">Установить</button> ' +
      '<button id="bgResetBtn" class="btn-secondary">Сбросить</button>' +
      (has ? '<p style="margin-top:10px;color:#16A34A;font-weight:700;">Кастомный фон установлен</p>' : '') + '</div>';
  }
  function renderHeroBlock() {
    var photos = getHeroPhotos();
    var thumbs = photos.map(function (p, i) { return '<div class="hero-thumb"><img src="' + p + '"><button onclick="window.__heroRemove(' + i + ')">✕</button></div>'; }).join('');
    return '<div class="admin-extras-section"><h3>Слайдер в шапке (Hero)</h3>' +
      '<p>До 10 фото. Автосмена каждые 4 секунды.</p>' +
      '<div class="form-group"><label>Фото:</label><input type="file" id="heroPhotosInput" accept="image/*" multiple></div>' +
      '<button id="heroAddBtn" class="btn-success">Добавить</button> ' +
      '<button id="heroClearBtn" class="btn-danger">Удалить все</button>' +
      (thumbs ? '<div class="hero-thumbs">' + thumbs + '</div>' : '') + '</div>';
  }
  function renderAiBlock() {
    var opts = Object.keys(tournamentsData).map(function (k) { return '<option value="' + k + '">' + tournamentsData[k].title + '</option>'; }).join('');
    return '<div class="admin-extras-section"><h3>AI-парсинг заявок</h3>' +
      '<p>Вставьте текст заявок из беседы или загрузите файл (.txt/.csv).</p>' +
      '<div class="form-row"><div class="form-group"><label>Турнир:</label><select id="aiTourney">' + opts + '</select></div></div>' +
      '<div class="ai-upload-zone" id="aiDropZone"><div class="ai-upload-icon">📁</div><div class="ai-upload-text">Перетащите файл или нажмите</div><input type="file" id="aiFileInput" accept=".txt,.csv,.md" style="display:none;"></div>' +
      '<div class="form-group"><label>Текст:</label><textarea id="aiTextarea" placeholder="ФК Химмаш:&#10;1. Аксёнов Амир&#10;2. Раджабов Руслан"></textarea></div>' +
      '<div class="ai-actions"><button id="aiParseBtn" class="btn-success">Распознать</button> <button id="aiClearBtn" class="btn-secondary">Очистить</button></div>' +
      '<div class="ai-status" id="aiStatus"></div></div>';
  }
  function renderVkMatcherBlock() {
    return '<div class="admin-extras-section"><h3>📡 Синхронизация трансляций ВК</h3>' +
      '<p>Вставьте список ссылок/постов из видеораздела группы <a href="https://vk.ru/lfldd" target="_blank" rel="noopener" style="color:#0077FF;">vk.ru/lfldd</a>. ' +
      'Алгоритм найдёт названия играющих клубов в заголовке и привяжет трансляцию к матчу.</p>' +
      '<div class="form-group"><label>Ссылки (по одной в строке):</label>' +
      '<textarea id="vkMatcherInput" placeholder="https://vk.com/video-123_456 ПТИМАШ — Металлист. Финал Кубка 5х5&#10;https://vk.com/video-123_789 Химмаш — Кабо-Верде. 1/4 Кубка"></textarea></div>' +
      '<div class="ai-actions"><button id="vkMatcherRun" class="btn-success">📡 Сопоставить и привязать</button></div>' +
      '<div class="ai-status" id="vkMatcherStatus"></div></div>';
  }
  function renderAiAssistantBlock() {
    var key = getAiKey();
    var prov = getAiProvider();
    return '<div class="admin-extras-section"><h3>🤖 AI-Ассистент пресс-службы</h3>' +
      '<p>Генерация обзора тура для публикации в сообществе ВК. Без API-ключа работает локальный генератор аналитики.</p>' +
      '<div class="form-row">' +
        '<div class="form-group"><label>Провайдер:</label>' +
          '<select id="aiAssistantProvider">' +
            '<option value="local"' + (prov === 'local' ? ' selected' : '') + '>Локальный (без API)</option>' +
            '<option value="openai"' + (prov === 'openai' ? ' selected' : '') + '>OpenAI</option>' +
            '<option value="deepseek"' + (prov === 'deepseek' ? ' selected' : '') + '>DeepSeek</option>' +
            '<option value="gemini"' + (prov === 'gemini' ? ' selected' : '') + '>Gemini</option>' +
          '</select>' +
        '</div>' +
        '<div class="form-group"><label>API-ключ (опционально):</label>' +
          '<input type="password" id="aiAssistantKey" value="' + (key ? '●●●●●●●●' : '') + '" placeholder="Вставьте ключ">' +
        '</div>' +
      '</div>' +
      '<div class="ai-actions">' +
        '<button id="aiSaveKeyBtn" class="btn-secondary">Сохранить настройки</button>' +
        '<button id="aiGenerateReportBtn" class="btn-success">📝 Сгенерировать обзор тура</button>' +
      '</div>' +
      '<div class="ai-assistant-output" id="aiAssistantOutput" style="display:none;"></div>' +
    '</div>';
  }
  function renderOrganizersBlock() {
    var list = (window.organizersData || []).map(function (c, i) {
      return '<div class="fixture-item"><span class="fixture-pair"><strong>' + (c.name || '') + '</strong>' + (c.role ? ' — ' + c.role : '') + (c.phone ? ' • ' + c.phone : '') + (c.vk ? ' • ' + c.vk : '') + '</span><button onclick="window.__orgRemove(' + i + ')" class="btn-danger" style="padding:5px 10px !important;font-size:11px;">Удалить</button></div>';
    }).join('');
    return '<div class="admin-extras-section"><h3>Контакты организаторов</h3>' +
      '<div class="form-row"><div class="form-group"><label>ФИО:</label><input type="text" id="orgName"></div>' +
      '<div class="form-group"><label>Роль:</label><input type="text" id="orgRole"></div></div>' +
      '<div class="form-row"><div class="form-group"><label>Телефон:</label><input type="text" id="orgPhone"></div>' +
      '<div class="form-group"><label>ВК / Telegram:</label><input type="text" id="orgVk"></div></div>' +
      '<button id="orgAddBtn" class="btn-success">Добавить контакт</button>' +
      (list ? '<div style="margin-top:14px;">' + list + '</div>' : '') + '</div>';
  }
  function renderConstructorBlock() {
    var cb = clubsData.map(function (c) { return '<label class="club-checkbox"><input type="checkbox" value="' + c.name.replace(/"/g, '&quot;') + '"><span>' + c.name + '</span></label>'; }).join('');
    return '<div class="admin-extras-section"><h3>Создание нового турнира</h3>' +
      '<div class="form-row"><div class="form-group"><label>Название:</label><input type="text" id="ntTitle"></div>' +
      '<div class="form-group"><label>Ключ:</label><input type="text" id="ntKey" placeholder="autumn_8x8"></div></div>' +
      '<div class="form-row"><div class="form-group"><label>Формат:</label><select id="ntFormat"><option>5x5</option><option>7x7</option><option>8x8</option><option>11x11</option></select></div>' +
      '<div class="form-group"><label>Статус:</label><select id="ntStatus"><option value="announce">Анонс</option><option value="live">Идёт</option><option value="done">Завершён</option></select></div></div>' +
      '<div class="form-group"><label>Участники:</label><div class="checkbox-list" id="ntClubsList">' + cb + '</div></div>' +
      '<button id="ntAddClubBtn" class="btn-secondary">+ Новый клуб</button> <button id="ntCreateBtn" class="btn-success">Создать</button>' +
      '<div id="ntNewClubForm" style="display:none;margin-top:16px;padding:16px;background:#F7FAFC;border-radius:8px;border:1px solid #E2E8F0;">' +
      '<h4>Новый клуб</h4><div class="form-group"><label>Название:</label><input type="text" id="ncName"></div>' +
      '<div class="form-group"><label>Эмблема:</label><input type="file" id="ncLogo" accept="image/*"></div>' +
      '<button id="ncSaveBtn" class="btn-success">Сохранить</button> <button id="ncCancelBtn" class="btn-danger">Отмена</button></div></div>';
  }
  function renderFixtureBlock() {
    var opts = Object.keys(tournamentsData).map(function (k) { return '<option value="' + k + '">' + tournamentsData[k].title + '</option>'; }).join('');
    return '<div class="admin-extras-section"><h3>Конструктор расписания</h3>' +
      '<div class="form-row"><div class="form-group"><label>Турнир:</label><select id="fbTourney">' + opts + '</select></div>' +
      '<div class="form-group"><label>Тур:</label><input type="text" id="fbTour" placeholder="1 ТУР" list="fbToursList"><datalist id="fbToursList"></datalist></div>' +
      '<div class="form-group"><label>Дата:</label><input type="text" id="fbDate" placeholder="08.06.2026 19:00"></div></div>' +
      '<div class="form-row"><div class="form-group"><label>Команда 1:</label><select id="fbT1"></select></div>' +
      '<div class="form-group"><label>Команда 2:</label><select id="fbT2"></select></div></div>' +
      '<div id="fbHint"></div>' +
      '<div style="margin-top:14px;"><button id="fbAddPairBtn" class="btn-success">Назначить</button> <button id="fbShowRemainingBtn" class="btn-secondary">Оставшиеся пары</button> <button id="fbRoundRobinBtn" class="btn-warn">Круговой календарь</button></div>' +
      '<div class="fixture-list" id="fbList"></div></div>';
  }

  function addOrganizer() {
    var name = (document.getElementById('orgName').value || '').trim();
    var role = (document.getElementById('orgRole').value || '').trim();
    var phone = (document.getElementById('orgPhone').value || '').trim();
    var vk = (document.getElementById('orgVk').value || '').trim();
    if (!name) return alert('Введите ФИО');
    if (!window.organizersData) return;
    window.organizersData.push({ name: name, role: role, phone: phone, vk: vk });
    if (window.saveOrganizers) window.saveOrganizers();
    renderAdminExtras();
    alert('Добавлено!');
  }
  function removeOrganizer(i) {
    if (!confirm('Удалить?')) return;
    if (!window.organizersData) return;
    window.organizersData.splice(i, 1);
    if (window.saveOrganizers) window.saveOrganizers();
    renderAdminExtras();
  }
  window.__orgRemove = removeOrganizer;

  function saveNewClub() {
    var n = (document.getElementById('ncName') || {}).value || '';
    n = n.trim();
    if (!n) return alert('Введите название');
    if (clubsData.find(function (c) { return c.name === n; })) return alert('Уже существует');
    var f = document.getElementById('ncLogo');
    var file = f && f.files ? f.files[0] : null;
    function finish(logo) {
      clubsData.push({ name: n, logo: logo || '⚽' });
      persistNewClub(n, logo || '⚽');
      if (window.renderSidebar) window.renderSidebar();
      renderAdminExtras(); alert('Клуб «' + n + '» зарегистрирован!');
    }
    if (file) { if (file.size > 500 * 1024) compressImage(file, 256, 0.9, finish); else { var r = new FileReader(); r.onload = function (e) { finish(e.target.result); }; r.readAsDataURL(file); } }
    else finish('');
  }
  function createTournament() {
    var title = (document.getElementById('ntTitle').value || '').trim();
    var key = (document.getElementById('ntKey').value || '').trim();
    if (!title) return alert('Введите название');
    if (!key) return alert('Введите ключ');
    if (!/^[a-z0-9_\-]+$/i.test(key)) return alert('Ключ: латиница');
    if (tournamentsData[key]) return alert('Ключ занят');
    var sel = [];
    document.querySelectorAll('#ntClubsList input[type="checkbox"]:checked').forEach(function (cb) { sel.push(cb.value); });
    if (sel.length < 2) return alert('Минимум 2 команды');
    var rosters = {}; sel.forEach(function (c) { rosters[c] = []; });
    tournamentsData[key] = { title: title, teams: sel, rosters: rosters, matches: [], awards: [], status: (document.getElementById('ntStatus') || {}).value || 'announce' };
    if (window.saveTournamentsToStorage) window.saveTournamentsToStorage();
    if (window.renderSidebar) window.renderSidebar();
    if (window.selectTourney) window.selectTourney(key);
    alert('Турнир создан!');
    renderAdminExtras();
  }

  /* ============================================================
     BIND EVENTS
     ============================================================ */
  function bindEvents() {
    ['bgSaveBtn'].forEach(function (id) { var b = document.getElementById(id); if (b) b.onclick = saveCustomBg; });
    var br = document.getElementById('bgResetBtn'); if (br) br.onclick = resetCustomBg;
    var ha = document.getElementById('heroAddBtn'); if (ha) ha.onclick = addHeroPhotos;
    var hc = document.getElementById('heroClearBtn'); if (hc) hc.onclick = clearHeroPhotos;

    var ap = document.getElementById('aiParseBtn'); if (ap) ap.onclick = runAiParse;
    var ac = document.getElementById('aiClearBtn'); if (ac) ac.onclick = function () { document.getElementById('aiTextarea').value = ''; document.getElementById('aiStatus').className = 'ai-status'; };
    var ad = document.getElementById('aiDropZone'); var af = document.getElementById('aiFileInput');
    if (ad && af) {
      ad.onclick = function () { af.click(); };
      af.onchange = function () { if (this.files[0]) handleAiFile(this.files[0]); };
      ad.ondragover = function (e) { e.preventDefault(); this.classList.add('dragover'); };
      ad.ondragleave = function () { this.classList.remove('dragover'); };
      ad.ondrop = function (e) { e.preventDefault(); this.classList.remove('dragover'); if (e.dataTransfer.files[0]) handleAiFile(e.dataTransfer.files[0]); };
    }

    // VK Matcher
    var vkRun = document.getElementById('vkMatcherRun'); if (vkRun) vkRun.onclick = runVkMatcher;

    // AI Assistant
    var aiSave = document.getElementById('aiSaveKeyBtn');
    var aiGen = document.getElementById('aiGenerateReportBtn');
    if (aiSave) aiSave.onclick = saveAiSettings;
    if (aiGen) aiGen.onclick = function () {
      var out = document.getElementById('aiAssistantOutput');
      if (out) out.style.display = 'block';
      runAiReport();
    };

    // Модалка предпросмотра
    var rpS = document.getElementById('rpSaveBtn'); if (rpS) rpS.onclick = saveRosterPreview;
    var rpC = document.getElementById('rpCancelBtn'); if (rpC) rpC.onclick = closeRosterPreview;
    var rpX = document.getElementById('rpCloseBtn'); if (rpX) rpX.onclick = closeRosterPreview;
    var rpM = document.getElementById('rosterPreviewModal'); if (rpM) rpM.onclick = function (e) { if (e.target === this) closeRosterPreview(); };

    // Клуб / турнир
    var ntA = document.getElementById('ntAddClubBtn'); if (ntA) ntA.onclick = function () { var f = document.getElementById('ntNewClubForm'); f.style.display = f.style.display === 'none' ? 'block' : 'none'; };
    var ncS = document.getElementById('ncSaveBtn'); if (ncS) ncS.onclick = saveNewClub;
    var ncC = document.getElementById('ncCancelBtn'); if (ncC) ncC.onclick = function () { document.getElementById('ntNewClubForm').style.display = 'none'; ['ncName', 'ncLogo'].forEach(function (id) { var el = document.getElementById(id); if (el) el.value = ''; }); };
    var ntC = document.getElementById('ntCreateBtn'); if (ntC) ntC.onclick = createTournament;
    document.querySelectorAll('.club-checkbox input').forEach(function (cb) { cb.onchange = function () { this.parentElement.classList.toggle('checked', this.checked); }; });

    // Fixture
    var fbT = document.getElementById('fbTourney'); if (fbT) fbT.onchange = updateFbTeams;
    ['fbTour', 'fbT1', 'fbT2'].forEach(function (id) { var el = document.getElementById(id); if (!el) return; el.onchange = updateFbHint; if (el.tagName === 'INPUT') el.oninput = updateFbHint; });
    var fbA = document.getElementById('fbAddPairBtn'); if (fbA) fbA.onclick = addFbPair;
    var fbR = document.getElementById('fbShowRemainingBtn'); if (fbR) fbR.onclick = showRemainingPairs;
    var fbRR = document.getElementById('fbRoundRobinBtn'); if (fbRR) fbRR.onclick = generateRoundRobin;

    // Протокол
    var mrT1 = document.getElementById('mrTab1'); if (mrT1) mrT1.onclick = function () { switchMrTeam(1); };
    var mrT2 = document.getElementById('mrTab2'); if (mrT2) mrT2.onclick = function () { switchMrTeam(2); };
    var mrS1 = document.getElementById('mrScore1'); if (mrS1) mrS1.oninput = function () { syncGoalsToScore(mrState.goals1, this.value); renderMrGoals(); validateMr(); };
    var mrS2 = document.getElementById('mrScore2'); if (mrS2) mrS2.oninput = function () { syncGoalsToScore(mrState.goals2, this.value); renderMrGoals(); validateMr(); };
    var mrC = document.getElementById('mrAddCardBtn'); if (mrC) mrC.onclick = addMrCard;
    var mrSv = document.getElementById('mrSaveBtn'); if (mrSv) mrSv.onclick = saveMatchResult;
    var mrX = document.getElementById('mrCancelBtn'); if (mrX) mrX.onclick = function () { document.getElementById('matchResultModal').style.display = 'none'; };
    var mrCl = document.getElementById('matchResultCloseBtn'); if (mrCl) mrCl.onclick = function () { document.getElementById('matchResultModal').style.display = 'none'; };
    var mrM = document.getElementById('matchResultModal'); if (mrM) mrM.onclick = function (e) { if (e.target === this) this.style.display = 'none'; };

    var orgA = document.getElementById('orgAddBtn'); if (orgA) orgA.onclick = addOrganizer;
  }

  window.__heroRemove = removeHeroPhoto;
  window.__fbDelete = function (tk, idx) {
    if (!confirm('Удалить матч?')) return;
    tournamentsData[tk].matches.splice(idx, 1);
    if (window.saveTournamentsToStorage) window.saveTournamentsToStorage();
    if (window.renderTourney) window.renderTourney();
    if (window.updateDynamicTabs) window.updateDynamicTabs();
    renderFbList();
  };
  window.__fbOpenResult = openMatchResult;
  window.__rpUpdateName = function (gi, pi, v) { if (rpState.groups[gi] && rpState.groups[gi].players[pi] !== undefined) rpState.groups[gi].players[pi] = v; };
  window.__rpMovePlayer = function (gi, pi, newClub) {
    var row = document.querySelector('.rp-player-row[data-gi="' + gi + '"][data-pi="' + pi + '"]'); if (!row) return;
    var n = row.querySelector('.rp-player-name'); var b = row.querySelector('.rp-status-badge');
    var allP = getAllRegisteredPlayers(); var st = determinePlayerStatus(n.value, newClub, allP);
    b.className = 'rp-status-badge ' + st.code; b.innerText = st.label;
  };
  window.__rpDeletePlayer = function (gi, pi) { var r = document.querySelector('.rp-player-row[data-gi="' + gi + '"][data-pi="' + pi + '"]'); if (r) r.remove(); };

  window.onAdminPanelOpened = function () { renderAdminExtras(); };

  function renderAdminExtras() {
    var c = document.getElementById('adminExtrasContainer'); if (!c) return;
    c.innerHTML = renderBackgroundBlock() + renderHeroBlock() + renderAiBlock() + renderVkMatcherBlock() + renderAiAssistantBlock() + renderOrganizersBlock() + renderConstructorBlock() + renderFixtureBlock();
    bindEvents();
    var fbT = document.getElementById('fbTourney');
    if (fbT && tournamentsData[fbT.value]) updateFbTeams();
  }

  loadCustomClubs(); applyBackground();
  if (document.getElementById('view-admin') && document.getElementById('view-admin').style.display === 'block') renderAdminExtras();
  console.log('[admin-extras] загружен');
})();